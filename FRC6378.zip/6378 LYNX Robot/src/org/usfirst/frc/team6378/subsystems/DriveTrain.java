package org.usfirst.frc.team6378.subsystems;

import org.usfirst.frc.team6378.utils.Mapping;

import edu.wpi.first.wpilibj.ADXRS450_Gyro;
import edu.wpi.first.wpilibj.CounterBase.EncodingType;
import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.RobotDrive;
import edu.wpi.first.wpilibj.SPI;
import edu.wpi.first.wpilibj.interfaces.Gyro;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

/**
 * Controls the robot drivetrain.
 * 
 * @author Omar Ashqar
 *
 */
public class DriveTrain extends RobotDrive {

	private final double AUTO_STRAIGHT_SPEED = 0.2;
	private final double AUTO_TURN_SPEED = 0.4;
	private final long sanicSeconds = 3;

	// -- Time auto state machine
	private final int TIMEAUTO_STRAIGHT_DRIVE = 0;
	private final int TIMEAUTO_STOP_STRAIGHT_DRIVE = 1;
	private final int TIMEAUTO_TURN = 2;
	private final int TIMEAUTO_TIME_DRIVE = 3;
	//private final int TIMEAUTO_VISION_DRIVE = 3;
	private int timeAutoState = TIMEAUTO_STRAIGHT_DRIVE;
	// -- Time auto
	
	// Subsystems
	private Gyro gyro;
	public Encoder encoder;

	/* AUTO */
	private final String timeAuto = "time";
	// -- slider 1: 3.15 seconds, slider 2: -0.0005 curve  
	private final String middleTimeAuto = "middle";
	private final String encoderAuto = "encoder";
	private final String middleAuto = "middleAuto";
	private final String middleSliderAuto = "midslid";
	private final String newAuto = "new";

	private final String rightSliderAuto = "rightslider";
	private final String leftSliderAuto = "leftslider";
	private final String boopAuto = "boop";

	private final String lbAuto = "lb";
	private final String rbAuto = "rb";
	private final String lrAuto = "lr";
	private final String rrAuto = "rr";
	
	private final String straightAuto = "straightAuto";

	private boolean reached = false;

	private long autoStartTime;

	/* AUTO CONSTANTS */
	private final double OFFSET_TIME = 1.5, OFFSET = 0.00001;
	//private final double kP = -0.005;
	private double kP = 0;
	private double fix = 0;

	// ???
	private long currTime;
	private double currAngle, currDistance, initialTime, straightCurve, turnVar, finalTime, kpValue;
	private boolean isReset = false;

	public DriveTrain(int frontLeftMotor, int rearLeftMotor, int frontRightMotor, int rearRightMotor) {
		super(frontLeftMotor, rearLeftMotor, frontRightMotor, rearRightMotor);

		gyro = new ADXRS450_Gyro(SPI.Port.kOnboardCS0);
		gyro.calibrate();

		encoder = new Encoder(Mapping.encoder_yellow, Mapping.encoder_blue, true, EncodingType.k4X);
		encoder.setDistancePerPulse(Math.PI * 6 / 1440);
		encoder.reset();
	}

	public void resetEncoder() {
		encoder.reset();
	}

	public void resetGyro() {
		gyro.reset();
	}

	public void initTimer() {
		autoStartTime = System.currentTimeMillis();
		reached = false;
		isReset = false;
	}

	public void leftAuto(double distanceSet, double angleSet) {
		if (currTime < OFFSET_TIME) // Straight
			drive(AUTO_STRAIGHT_SPEED, OFFSET);
		else if (currTime < distanceSet && !reached) // Straight
			drive(AUTO_STRAIGHT_SPEED, 0);
		else if (currAngle < angleSet) { // Turn
			reached = true;
			drive(AUTO_TURN_SPEED, 1);
		} else if (currDistance < 200) // Straight
			drive(AUTO_STRAIGHT_SPEED, 0);
	}

	public void rightAuto(double distanceSet, double angleSet) {
		if (currTime < OFFSET_TIME) // Straight
			drive(AUTO_STRAIGHT_SPEED, OFFSET);
		else if (currTime < distanceSet && !reached) // Straight
			drive(AUTO_STRAIGHT_SPEED, 0);
		else if (currAngle < angleSet) { // Turn
			reached = true;
			drive(AUTO_TURN_SPEED, -1);
		} else if (currDistance < 200) // Straight
			drive(AUTO_STRAIGHT_SPEED, 0);
	}

	public void driveAuto(String autoSelected) {

		// SmartDashboard.getDouble("DB/Slider 0")
		currTime = (System.currentTimeMillis() - autoStartTime) / 1000;
		currAngle = Math.abs(gyro.getAngle());
		currDistance = Math.abs(encoder.getDistance());

		//initialTime = SmartDashboard.getDouble("DB/Slider 0");
		kpValue = SmartDashboard.getDouble("DB/Slider 0");
		straightCurve = SmartDashboard.getDouble("DB/Slider 1");
		turnVar = SmartDashboard.getDouble("DB/Slider 2");
		finalTime = SmartDashboard.getDouble("DB/Slider 3");
		
		

		switch (autoSelected) {

		case boopAuto:
			if (currTime < straightCurve) {
				double fix = kP * gyro.getAngle();
				drive(initialTime, fix);
			}
			break;

		case leftSliderAuto:
			leftAuto(initialTime, straightCurve);
			break;

		case rightSliderAuto:
			rightAuto(initialTime, straightCurve);
			break;

		case lbAuto:
			leftAuto(initialTime, straightCurve);
			break;

		case rbAuto:
			rightAuto(initialTime, straightCurve);
			break;

		case lrAuto:
			if (currTime < straightCurve) {
				double fix = kP * gyro.getAngle();
				drive(initialTime, fix);
			} else if (currAngle < turnVar && !isReset) { // Turn
				drive(initialTime, 1);
			} else if (currTime < 10) {
				if (!isReset) {
					isReset = true;
					gyro.reset();
				}
				double fix = kP * gyro.getAngle();
				drive(initialTime, fix);
			}
			break;

		case rrAuto:
			if (currTime < straightCurve) {
				double fix = kP * gyro.getAngle();
				drive(initialTime, fix);
			} else if (currAngle < turnVar && !isReset) { // Turn
				drive(initialTime, -1);
			} else if (currTime < 10) {
				if (!isReset) {
					isReset = true;
					gyro.reset();
				}
				double fix = kP * gyro.getAngle();
				drive(initialTime, fix);
			}
			break;

		case middleTimeAuto:
			if (currTime < initialTime)
				drive(AUTO_STRAIGHT_SPEED, straightCurve);
			else
				drive(0,0);
			break;
		/*	
		case timeAuto:
			if (currTime < slider1)
				drive(AUTO_STRAIGHT_SPEED, slider2);
			else if( currTime >= slider1 + 0.5)
				drive(0, 0);
			else if( currTime )
			break;
		*/
				
		case timeAuto:
			if (currTime < initialTime)
				drive(AUTO_STRAIGHT_SPEED, straightCurve);
			else if( currTime < initialTime + 0.5)
				drive(0,0);
			else if( currTime < initialTime + 1.5)
				drive(0.3, turnVar);
			else if( currTime < finalTime )
				drive( AUTO_STRAIGHT_SPEED , straightCurve);
			else
				drive(0,0);
			break;

		/*
		case timeAuto:
		{
		    switch( timeAutoState )
		    {
		        case TIMEAUTO_STRAIGHT_DRIVE:
		        {
		        	
				    if (currTime < slider1)
				    {
				        drive(AUTO_STRAIGHT_SPEED, slider2);
				    }
				    else
				    {
				        timeAutoState = TIMEAUTO_STOP_STRAIGHT_DRIVE;
				    }
		        }
		        break;
		        // -- optional case
		        case TIMEAUTO_STOP_STRAIGHT_DRIVE:
		        {
		            drive(0,0);
		            timeAutoState = TIMEAUTO_TURN;
		        }
		        break;
		        case TIMEAUTO_TURN:
		        {
		            // -- slider 3 counts from start (time + slider 1)
		            if (currTime < slider4)
				    {
				        drive(AUTO_STRAIGHT_SPEED, slider3 );
				    }
				    else
				    {
				        drive( 0, 0 );
				    	//timeAutoState = TIMEAUTO_TIME_DRIVE;
				    }
		        }
		        break;
		        /*case TIMEAUTO_TIME_DRIVE:
		        {
		        	drive(AUTO_STRAIGHT_SPEED, slider2);
		        }
		        
		        case TIMEAUTO_VISION_DRIVE:
		        {
		            drive( AUTO_STRAIGHT_SPEED, 0 );
		        }
		        break;
		    
		    }
		}
		break;	
		*/
		case encoderAuto:
			if (currDistance < 32)
				drive(AUTO_STRAIGHT_SPEED, 0);
			else
				drive(0,0);
			break;
			
		case straightAuto:
			drive(AUTO_STRAIGHT_SPEED, -0.3);

		case middleSliderAuto:
			if (currTime < OFFSET_TIME)
				drive(initialTime, straightCurve);
			else if (currTime < turnVar)
				drive(initialTime, 0);
			break;
		
		case newAuto:
			currAngle = gyro.getAngle();
			kP = kpValue;
			fix = kP * gyro.getAngle();
			drive( AUTO_STRAIGHT_SPEED, -fix );
			break;
			
		case middleAuto:
		default:
			if (currTime < OFFSET_TIME)
				drive(AUTO_STRAIGHT_SPEED, OFFSET);
			else if (currTime < 5)
				drive(AUTO_STRAIGHT_SPEED, 0);
			break;

		} // End of Switch

		tick();
	}

	public void tick() {
		SmartDashboard.putString("DB/String 0", "Distance: " + encoder.getDistance());
		SmartDashboard.putString("DB/String 1", "Current angle: " + gyro.getAngle());
		SmartDashboard.putString("DB/String 2", "Time: " + currTime);
		SmartDashboard.putString("DB/String3", "kp caluclations: " + fix);
	}
}
